=========
CdefSlave
=========

.. autoclass:: pysoem.CdefSlave
   :members:
   :inherited-members: