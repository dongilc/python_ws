======
Master
======

.. autoclass:: pysoem.Master
   :members:
   :inherited-members: