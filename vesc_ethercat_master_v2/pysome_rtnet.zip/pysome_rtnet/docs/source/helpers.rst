=======
Helpers
=======


.. autofunction:: pysoem.find_adapters

.. autofunction:: pysoem.al_status_code_to_string