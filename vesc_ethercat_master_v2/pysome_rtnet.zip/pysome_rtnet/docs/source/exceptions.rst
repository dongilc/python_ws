==========
Exceptions
==========


.. autoclass:: pysoem.SdoError
   :members:

.. autoclass:: pysoem.SdoInfoError
   :members:

.. autoclass:: pysoem.MailboxError
   :members:

.. autoclass:: pysoem.PacketError
   :members:

.. autoclass:: pysoem.ConfigMapError
   :members:

.. autoclass:: pysoem.EepromError
   :members: