============
Installation
============

.. code:: bash

   $ pip install pysoem