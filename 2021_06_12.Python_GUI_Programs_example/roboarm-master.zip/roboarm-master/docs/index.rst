.. roboarm documentation master file, created by
   sphinx-quickstart on Tue Aug  6 18:42:16 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to roboarm's documentation!
===================================

Python library for controlling owi robotic arm edge.

Contents:

.. toctree::
   :maxdepth: 2

   installation
   api


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

