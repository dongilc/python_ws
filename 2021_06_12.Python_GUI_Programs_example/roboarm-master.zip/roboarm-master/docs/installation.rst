************
Installation
************

You can install stable version from pypi:

.. code-block:: bash

    pip install roboarm

Or developer version from git:

.. code-block:: bash

    git clone git@github.com:nvbn/roboarm.git
    cd roboarm
    python setup.py develop
